﻿// <copyright file="$fileinputname$.cs" company="$registeredorganization$">
//  Copyright © $registeredorganization$. All Rights Reserved.
// </copyright>

namespace $rootnamespace$
{
    /// <summary>
    /// $safeitemrootname$
    /// </summary>
    /// <remarks>
    /// <para>
    /// This enumeration represents special values for $safeitemrootname$ column 
    /// of the ??? database table. T4 code generation template $fileinputname$View.tt
    /// is used to generate a SQL view in $fileinputname$View.sql based on enumerated
    /// values defined here. 
    /// </para>
    /// <para>
    /// Use this view to access values from this enumeration in T-SQL code. For example:
    /// </para>
    /// <example>
    /// declare @Item1 int
    /// select @Item1 = Item1 from enum.$safeitemrootname$
    /// </example>
    /// </remarks>
    public enum $safeitemrootname$
    {
        Item1,
        Item2
    }
}
