' <copyright file="$fileinputname$.vb" company="$registeredorganization$">
'  Copyright � $registeredorganization$. All Rights Reserved.
' </copyright>
Imports T4Toolbox

Partial Public Class $fileinputname$
    Inherits Generator

    Protected Overrides Sub RunCore()

    End Sub

    Protected Overrides Sub Validate()
        Me.Warning("Generator properties have not been validated")
    End Sub

End Class