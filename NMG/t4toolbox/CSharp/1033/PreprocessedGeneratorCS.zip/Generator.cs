// <copyright file="$fileinputname$.cs" company="$registeredorganization$">
//  Copyright � $registeredorganization$. All Rights Reserved.
// </copyright>

namespace $rootnamespace$
{
	using System;
	using T4Toolbox;

	public partial class $fileinputname$ : Generator
	{
        protected override void RunCore()
        {

        }

        protected override void Validate()
        {
            this.Warning("Generator properties have not been validated");
        }
    }
}
