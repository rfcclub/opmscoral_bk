// <copyright file="$fileinputname$.partial.cs" company="$registeredorganization$">
//  Copyright � $registeredorganization$. All Rights Reserved.
// </copyright>

namespace $rootnamespace$
{
	using System;
	using T4Toolbox;

	public partial class $fileinputname$
	{
        protected override void Validate()
        {
            this.Warning("Template properties have not been validated");
        }
    }
}
