' <copyright file="$fileinputname$.partial.vb" company="$registeredorganization$">
'  Copyright � $registeredorganization$. All Rights Reserved.
' </copyright>
Imports T4Toolbox

Partial Public Class $fileinputname$ 
	Inherits Template

    Protected Overrides Sub Validate()
        Me.Warning("Template properties have not been validated")
    End Sub

End Class